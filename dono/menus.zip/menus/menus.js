const menu = (prefix, NomeDoBot, sender) => {
  
// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
╭───────────────┐
├── MENU DE COMANDOS 
├───────────────
│ Usuário: @${sender.split("@")[0]}
├───────────────┐
│ COMANDOS TERMUX
╞───────────────┘
│✾▹ ${prefix}Comandos-termux
│✾▹ ${prefix}Configurar-bot
│✾▹ ${prefix}Git-bot
╰──────────┐
╭──────────┴─┐
│ INFO - DONO - ADM
├────────────
│✾▹ ${prefix}infolimitarcomando
│✾▹ ${prefix}infoAluguel
│✾▹ ${prefix}infopremium
│✾▹ ${prefix}infoforca
│✾▹ ${prefix}Infoduelo
│✾▹ ${prefix}Infotransmitir
│✾▹ ${prefix}InfoMultiPrefixo
│✾▹ ${prefix}InfoBemvindo
│✾▹ ${prefix}Infopalavrão
│✾▹ ${prefix}Infolistanegra
│✾▹ ${prefix}Infobancarac
│✾▹ ${prefix}Infovotação
│✾▹ ${prefix}InfoBanghost
│✾▹ ${prefix}Infosorteio 
│✾▹ ${prefix}InfoAnotação
│✾▹ ${prefix}infogold
╰──────────┐
╭──────────┴─┐
│ DIVERSOS MENUS
├────────────
│✾▹ ${prefix}Menudono
│✾▹ ${prefix}Menuadm
│✾▹ ${prefix}Menupremium
│✾▹ ${prefix}Efeitosimg
│✾▹ ${prefix}Logos
│✾▹ ${prefix}Brincadeiras
│✾▹ ${prefix}menugold
╰──────────┐
╭──────────┴─┐
│ COMANDOS DE MEMBRO
├────────────
│✾▹ ${prefix}Infobot
│✾▹ ${prefix}Idiomas 
│✾▹ ${prefix}Bug (QUESTIONE) 
│✾▹ ${prefix}Sugestao (DICA) 
│✾▹ ${prefix}Avalie (O-QUAO-BOM) 
╰──────────┐
╭──────────┴─┐
│ PESQUISAS/BAIXAR
├────────────
│✾▹ ${prefix}Play (NOME) 
│✾▹ ${prefix}Playmp4 (NOME)
│✾▹ ${prefix}playstore ( NOME )
│✾▹ ${prefix}Ytsearch (NOME)
│✾▹ ${prefix}Ytmp4 (LINK) 
│✾▹ ${prefix}Ytmp3 (LINK) 
│✾▹ ${prefix}Tiktok (LINK) 
│✾▹ ${prefix}Instagram (LINK) 
│✾▹ ${prefix}Facebook (LINK) 
│✾▹ ${prefix}Twitter (LINK) 
│✾▹ ${prefix}Imgpralink (MARCAR)
│✾▹ ${prefix}Videopralink (MARCAR-V)
│✾▹ ${prefix}Amazon (EXEMPLO: Celular A13)
│✾▹ ${prefix}grupos ( Exemplo: Naruto )
╰──────────┐
╭──────────┴─┐
│ INFORMAÇÕES 
├────────────
│✾▹ ${prefix}Ping (VELO) 
│✾▹ ${prefix}Gitdobot
│✾▹ ${prefix}Atividade
│✾▹ ${prefix}Rankativo
│✾▹ ${prefix}Checkativo (@MARCAR)
│✾▹ ${prefix}moedas
╰──────────┐
╭──────────┴─┐
│ JOGOS
├────────────
│✾▹ ${prefix}Iniciar_forca
│✾▹ ${prefix}Ppt (PEDRA/PAPEL/TESOURA) 
│✾▹ ${prefix}Jogodavelha (@MARCAR) 
│✾▹ ${prefix}Cassino
╰──────────┐
╭──────────┴─┐
│ FIGURINHAS
├────────────
│✾▹ ${prefix}Attp (TEXTO)
│✾▹ ${prefix}Attp2 (TEXTO)
│✾▹ ${prefix}Fsticker (MARCAR-FOTO)
│✾▹ ${prefix}Sticker (MARCAR-FOTO)
│✾▹ ${prefix}Toimg (MARCAR-FIGU)
│✾▹ ${prefix}Togif (MARCAR-FIGU)
│✾▹ ${prefix}Roubar (TEXT/TEXT)
│✾▹ ${prefix}fig
│✾▹ ${prefix}figdesenho
│✾▹ ${prefix}figengracada
│✾▹ ${prefix}figraiva
│✾▹ ${prefix}figcoreana
│✾▹ ${prefix}figanime
│✾▹ ${prefix}figmeme
│✾▹ ${prefix}figroblox
│✾▹ ${prefix}figemoji
╰──────────┐
╭──────────┴─┐
│ COMANDOS/BÁSICOS
├────────────
│✾▹ ${prefix}esporte_noticias
│✾▹ ${prefix}celular ( Ex: Galaxy a9 )
│✾▹ ${prefix}Gtts (LINGUAGEM + TEXTO)
│✾▹ ${prefix}Tagme 
│✾▹ ${prefix}Emoji 😏/whatsapp
│✾▹ ${prefix}Emojimix 😉+🙂
│✾▹ ${prefix}Tabela (LETRAS) 
│✾▹ ${prefix}Conselhobiblico
│✾▹ ${prefix}Simi (FALE-ALGO)  
│✾▹ ${prefix}Perfil
│✾▹ ${prefix}Calcular 1 + 1
│✾▹ ${prefix}Fazernick (NICK)
│✾▹ ${prefix}Bot
│✾▹ ${prefix}signo ( EX: virgem)
│✾▹ ${prefix}metadinha
│✾▹ ${prefix}tomp3 ( VIDEO > PRA AUDIO)
╰──────────┘

`;
};

exports.menu = menu;

// MENU DE ADMINISTRADORES 

const adms = (prefix, sender) => { 
 
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

	return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
╭───────────────┐
├── MENU DE ADMS
├───────────────
│ Usuário: @${sender.split("@")[0]}
╞───────────────┘
│✾▹ ${prefix}ativacoes
│✾▹ ${prefix}so_adm
│✾▹ ${prefix}listanegra (NUMERO)
│✾▹ ${prefix}tirardalista (NUMERO)
│✾▹ ${prefix}listanegraG (NÚMERO)
│✾▹ ${prefix}tirardalistaG (NÚMERO)
│✾▹ ${prefix}Kick [@] (pra-remover) 
│✾▹ ${prefix}Ban (responder-mensagem)
│✾▹ ${prefix}Promover [@] (Ser-ADM)
│✾▹ ${prefix}Rebaixar [@] (rebaixar-adm)
│✾▹ ${prefix}Totag (menciona-algo)
│✾▹ ${prefix}Grupo f/a
│✾▹ ${prefix}Status
│✾▹ ${prefix}Limpar (texto-invisível-gp)
│✾▹ ${prefix}Atividades (DO-GRUPO)
│✾▹ ${prefix}Linkgp
│✾▹ ${prefix}Grupoinfo
│✾▹ ${prefix}Hidetag (txt) (marcação)
│✾▹ ${prefix}Marcar (marca tds do gp)
│✾▹ ${prefix}Marcar2 (Marca-tds-Wa.me/)
│✾▹ ${prefix}Antipalavra 1 / 0
│✾▹ ${prefix}Descgp (TXT)
│✾▹ ${prefix}Nomegp (Nome)
│✾▹ ${prefix}Criartabela (ESCREVA-ALGO)
│✾▹ ${prefix}Tabelagp
╰──────────┘

`;
};

exports.adms = adms;

// MENU DE DONO

const menudono = (prefix, sender) => {
	
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode alterar ele tod0, menos as definições, só se quiser apagar a definição completa. 	

return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
	
╭───────────────┐
├── MENU DE DONO
├───────────────
│ Usuário: @${sender.split("@")[0]}
├───────────────┐
│ Config: ${prefix}Configurar-bot
╞───────────────┘
│✾▹ ${prefix}ativacoes_dono
│✾▹ ${prefix}Bangp
│✾▹ ${prefix}Unbangp
│✾▹ ${prefix}Fotomenu (MARCAR-IMG) 
│✾▹ ${prefix}Blockcmd  (cmd)
│✾▹ ${prefix}Unblockcmd (cmd)
│✾▹ ${prefix}Legenda_estrangeiro (msg)
│✾▹ ${prefix}Legendabv (oq qr)
│✾▹ ${prefix}Legendasaiu (oq qr)
│✾▹ ${prefix}Legendasaiu2 (oq qr)
│✾▹ ${prefix}Legendabv2 (oq qr)
│✾▹ ${prefix}Fundobemvindo (marcar-img)
│✾▹ ${prefix}Fundosaiu (marcar-img)
│✾▹ ${prefix}Serpremium
│✾▹ ${prefix}Listagp
│✾▹ ${prefix}Antipalavrão 1 / 0
│✾▹ ${prefix}Antiligar 1 / 0
│✾▹ ${prefix}Addpalavra (palavrão)
│✾▹ ${prefix}Delpalavra (palavrão)
│✾▹ ${prefix}Ativo
│✾▹ ${prefix}Ausente (fale-oq-faz)
│✾▹ ${prefix}Delpremium @(marca)
│✾▹ ${prefix}Addpremium @(marca)
│✾▹ ${prefix}Clonar [@] (rouba ft de prf)
│✾▹ ${prefix}Fotobot (img, = foto do BT)
│✾▹ ${prefix}Descriçãogp (digite-algo)
│✾▹ ${prefix}Block [@] (bloq de usar cmds) 
│✾▹ ${prefix}Unblock [@] (desbloquear) 
│✾▹ ${prefix}Setprefix  (prefixo-novo)
│✾▹ ${prefix}Bcgp (TM-PRA-PV-MEMBROS)
╰──────────┘
`;

};

exports.menudono = menudono;

// MENU DE LOGOS 

const menulogos = (prefix, sender) => {
  
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
  return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​

╭───────────────┐
├── MENU DE LOGOS
├───────────────
│ Usuário: @${sender.split("@")[0]}
╰──────────┐
╭──────────┴─┐
│ Logos De 1 Texto
├────────────
│✾▹ ${prefix}logos1 (txt) 
│
╰──────────┘
`;
};

exports.menulogos = menulogos;

// MENU DE ALTERAR ÁUDIOS E VÍDEOS

const alteradores = (prefix, sender) => {

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return`
╭───────────────┐
├ Alteradores de audio/video 
├───────────────
│ Usuário: @${sender.split("@")[0]}
╰──────────┐
╭──────────┴─┐
│ Alterar Videos
├────────────
│✾▹ ${prefix}Videolento (marca)
│✾▹ ${prefix}Videorapido (marca)
│✾▹ ${prefix}Videocontrario (marca)
╰──────────┐
╭──────────┴─┐
│ Alterar Audios
├────────────
│✾▹ ${prefix}Audiolento (marca)
│✾▹ ${prefix}Audiorapido (marca)
│✾▹ ${prefix}Grave (marca)
│✾▹ ${prefix}Grave2 (marca)
│✾▹ ${prefix}Esquilo (marca)
│✾▹ ${prefix}Estourar (marca)
│✾▹ ${prefix}Bass (marca)
│✾▹ ${prefix}Bass2 (marca)
│✾▹ ${prefix}Vozmenino (marca)
│✾▹ ${prefix}Audioreverse (marca)
╰──────────┘
`;
};

exports.alteradores = alteradores;

// MENU PREMIUM 

const menuprem = (prefix, sender) => { 

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return `
╭───────────────┐
├─ Menu Premium
├───────────────
│ Usuário: @${sender.split("@")[0]}
╰──────────┐
╭──────────┴─┐
│✾▹ ADICIONE SEUS COMANDOS PREMIUM / VEJA O ${prefix}infopremium
╰──────────┘
`;
};

exports.menuprem = menuprem;

// MENU DE BRINCADEIRAS.. 

const brincadeiras = (prefix, sender) => {

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​

╭───────────────┐
├─ Menu De Brincadeiras
├───────────────
│ Usuário: @${sender.split("@")[0]}
╰──────────┐
╭──────────┴─┐
│✾▹ ${prefix}Gay (marca (@))
│✾▹ ${prefix}Feio (marca (@))
│✾▹ ${prefix}Corno (marca (@))
│✾▹ ${prefix}Vesgo (marca (@))
│✾▹ ${prefix}Bebado (marca (@))
│✾▹ ${prefix}Gostoso (marca (@))
│✾▹ ${prefix}Gostosa (marca (@))
│✾▹ ${prefix}Beijo (marca (@))
│✾▹ ${prefix}Matar (marca (@))
│✾▹ ${prefix}Tapa (marca (@))
│✾▹ ${prefix}Chute (marca (@))
│✾▹ ${prefix}Dogolpe (marca (@))   
│✾▹ ${prefix}Nazista (marca (@))
│✾▹ ${prefix}Chance (fale algo) 
│✾▹ ${prefix}Casal   
│✾▹ ${prefix}Rankgay     
│✾▹ ${prefix}Rankgado
│✾▹ ${prefix}Rankcorno  
│✾▹ ${prefix}Rankgostoso
│✾▹ ${prefix}Rankgostosa
│✾▹ ${prefix}Ranknazista
│✾▹ ${prefix}Rankotakus
│✾▹ ${prefix}Rankpau
╰──────────┘
`;
};

exports.brincadeiras = brincadeiras;

// MENU DE EFEITOS DE IMAGEM, MONTAGEM Tops Kkk

const efeitos = (prefix, sender) => {

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
╭───────────────┐
├─ Menu De Efeitos
├───────────────
│ Usuário: @${sender.split("@")[0]}
╰──────────┐
╭──────────┴─┐
│✾▹ ${prefix}Legenda (marcar)-(img)
│✾▹ ${prefix}Procurado (marcar)-(img)
│✾▹ ${prefix}Hitler (marcar)-(img)
│✾▹ ${prefix}Preso (marcar)-(img)
│✾▹ ${prefix}Lixo (marcar)-(img)
│✾▹ ${prefix}Deletem (marcar)-(img)
│✾▹ ${prefix}Morto (marcar)-(img) 
│✾▹ ${prefix}Lgbt (marcar)-(img) 
│
╰──────────┘
`;
};

exports.efeitos = efeitos;