const menudono = (prefix, EmojiBot) => {
	
	
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 	

return `
	
╭━━━━━◉                            
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗    
┆    ║     *${EmojiBot}️𝑴𝑬𝑵𝑼 𝑫𝑶𝑵𝑶${EmojiBot}️*           
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝    
╰━━━━━◉                     
‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
▢ ⌁ᴀᴘᴇɴᴀs ᴅᴏɴᴏ,ᴠᴀʀɪᴀs ғᴜɴᴄ̧ᴏ̃ᴇs⌁ ▢ 
╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║
┆    ║✼${EmojiBot}️ ${prefix}serpremium
┆    ║✼${EmojiBot}️ ${prefix}seradm
┆    ║✼${EmojiBot} ${prefix}sermembro
┆    ║✼${EmojiBot} ${prefix}revogarlink
┆    ║✼${EmojiBot} ${prefix}setlinkdivu
┆    ║✼${EmojiBot} ${prefix}divugg
┆    ║✼${EmojiBot} ${prefix}nuke (ARQUIVAR GP)
┆    ║✼${EmojiBot}️ ${prefix}zerar_rank
┆    ║✼${EmojiBot}️ ${prefix}addpalavra (palavrão)
┆    ║✼${EmojiBot}️ ${prefix}delpalavra (palavrão)
┆    ║✼${EmojiBot}️ ${prefix}blockcmd  (cmd)
┆    ║✼${EmojiBot}️ ${prefix}unblockcmd (cmd)
┆    ║✼${EmojiBot}️ ${prefix}ativo
┆    ║✼${EmojiBot}️ ${prefix}ausente (fale-oq-faz)
┆    ║✼${EmojiBot}️ ${prefix}delpremium @(marca)
┆    ║✼${EmojiBot}️ ${prefix}addpremium @(marca)
┆    ║✼${EmojiBot}️ ${prefix}limpar (limpa tds conversas)
┆    ║✼${EmojiBot}️ ${prefix}block [@] (bloq de usar cmds)
┆    ║✼${EmojiBot}️ ${prefix}unblock [@] (desbloquear) 
┆    ║✼${EmojiBot}️ ${prefix}block-temp [@] (tempo)
┆    ║✼${EmojiBot}️ ${prefix}unblock-temp [@]
┆    ║✼${EmojiBot} ${prefix}banghost 0
┆    ║✼${EmojiBot}️ ${prefix}bangp
┆    ║✼${EmojiBot}️ ${prefix}unbangp
┆    ║✼${EmojiBot}️ ${prefix}bcgp (TM-PRA-PV-MEMBROS)
┆    ║✼${EmojiBot} ${prefix}reviverqr
┆    ║✼${EmojiBot} ︎${prefix}join (linkgp)
┆    ║✼${EmojiBot}️ ${prefix}listagp
┆    ║✼${EmojiBot}️ ${prefix}listagp2
┆    ║✼${EmojiBot}️ ${prefix}listacomunidades
┆    ║✼${EmojiBot}️ ${prefix}infogp
┆    ║✼${EmojiBot}️ ${prefix}sairgp
┆    ║✼${EmojiBot}️ ${prefix}figpack (legenda)
┆    ║✼${EmojiBot}️ ${prefix}figauthor (legenda)
╰━━━━━◉                
    
╭━━━━━◉                            
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗    
┆    ║     *${EmojiBot}️𝐂𝐎𝐍𝐅𝐈𝐆𝐔𝐑𝐀𝐑-𝐁𝐎𝐓${EmojiBot}️*           
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝    
╰━━━━━◉                
╭━━━━━◉                    
┆    ║✼${EmojiBot}️ ${prefix}so_adm 1 / 0
┆    ║✼${EmojiBot} ${prefix}botoes
┆    ║✼${EmojiBot} ${prefix}nome-bot
┆    ║✼${EmojiBot} ${prefix}numero-dono
┆    ║✼${EmojiBot} ${prefix}nick-dono
┆    ║✼${EmojiBot} ${prefix}prefixo-bot
┆    ║✼${EmojiBot} ${prefix}fotobot
┆    ║✼${EmojiBot}️ ${prefix}fotomenu (marca-img)
┆    ║✼${EmojiBot}️ ${prefix}fotobot (img, = foto do BOT)
┆    ║✼${EmojiBot}️ ${prefix}antiligar 1 / 0
┆    ║✼${EmojiBot}️ ${prefix}antipv 1 / 0 (esse da block)
┆    ║✼${EmojiBot}️ ${prefix}antipv2 1 / 0 (msg)
┆    ║✼${EmojiBot}️ ${prefix}antipv3 1 / 0 (ignora)
┆    ║✼${EmojiBot}️ ${prefix}antipalavrão 1 / 0
┆    ║✼${EmojiBot}️ ${prefix}dono2 @marca
┆    ║✼${EmojiBot}️ ${prefix}dono3 @marca
┆    ║✼${EmojiBot}️ ${prefix}dono4 @marca
┆    ║✼${EmojiBot}️ ${prefix}dono5 @marca
┆    ║
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉
`
}
exports.menudono = menudono







