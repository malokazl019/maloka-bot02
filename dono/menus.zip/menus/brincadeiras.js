const brincadeiras = (prefix, EmojiBot) => {

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return `
╭━━━━━◉         
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗    
┆    ║       *${EmojiBot}️𝑩𝑹𝑰𝑵𝑪𝑨𝑫𝑬𝑰𝑹𝑨𝑺${EmojiBot}️*   
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝    
╰━━━━━◉     
‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
▢ ⌁ᴍᴇɴᴜ ᴅᴇ ʙʀɪɴᴄᴀᴅᴇɪʀᴀs,ʙʀɪǫᴜᴇ ᴄᴏᴍ sᴇᴜs ᴀᴍɪɢᴏs⌁ ▢ 
╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║
┆    ║✼${EmojiBot}️ ${prefix}Gay (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}hetero (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Feio (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Corno (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Vesgo (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Bebado (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Gostoso (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Gostosa (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Beijo (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}abraco (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Matar (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Tapa (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Chute (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Dogolpe (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Nazista (marca (@))
┆    ║✼${EmojiBot}️ ${prefix}Chance (fale algo) 
┆    ║✼${EmojiBot}️ ${prefix}bmc
┆    ║✼${EmojiBot}️ ${prefix}ceu
┆    ║✼${EmojiBot}️ ${prefix}inferno
┆    ║✼${EmojiBot}️ ${prefix}webcorno  (@)
┆    ║✼${EmojiBot}️ ${prefix}vdd_desafio
┆    ║✼${EmojiBot}️ ${prefix}Casal   
┆    ║✼${EmojiBot}️ ${prefix}golpista
┆    ║✼${EmojiBot}️ ${prefix}shipo @1 @2
┆    ║✼${EmojiBot}️ ${prefix}kiss @1 @2
┆    ║✼${EmojiBot}️ ${prefix}Rankpau
┆    ║✼${EmojiBot}️ ${prefix}gadometro
┆    ║✼${EmojiBot}️ ${prefix}Rankgay    
┆    ║✼${EmojiBot}️ ${prefix}Rankgolpe
┆    ║✼${EmojiBot}️ ${prefix}Rankgado
┆    ║✼${EmojiBot}️ ${prefix}Rankcorno  
┆    ║✼${EmojiBot}️ ${prefix}Rankgostoso
┆    ║✼${EmojiBot}️ ${prefix}Rankgostosa
┆    ║✼${EmojiBot}️ ${prefix}Ranknazista
┆    ║✼${EmojiBot}️ ${prefix}Rankotakus
┆    ║✼${EmojiBot}️ ${prefix}Rankpau
┆    ║
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉
    
╭━━━━━◉         
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗    
┆    ║  *${EmojiBot}️𝐆𝐀𝐌𝐄𝐒${EmojiBot}️*
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝    
╰━━━━━◉     
╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║
┆    ║✼${EmojiBot}️ ${prefix}roleta
┆    ║✼${EmojiBot}️ ${prefix}eujaeununca
┆    ║✼${EmojiBot} ${prefix}akinator
┆    ║✼${EmojiBot}️ ${prefix}forca
┆    ║✼${EmojiBot}️ ${prefix}jogodavelha
┆    ║✼${EmojiBot} ${prefix}Ttt 
┆    ║✼${EmojiBot}️ ${prefix}ppt
┆    ║✼${EmojiBot}️ ${prefix}ppt2
┆    ║✼${EmojiBot} ${prefix}Quizanimais 
┆    ║✼${EmojiBot} ${prefix}Anagrama 
┆    ║✼${EmojiBot}️ ${prefix}rankanagrama 
┆    ║✼${EmojiBot}️ ${prefix}tinder
┆    ║✼${EmojiBot}️ ${prefix}sairtinder
┆    ║
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰━━━━━◉ 
    
╭━━━━━◉
╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
║  ${EmojiBot}𝐀𝐃𝐌${EmojiBot}
╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰━━━━━◉

╭━━━━━◉
┆  ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆  ║✼${EmojiBot} ${prefix}sistemgold
┆  ║✼${EmojiBot} ${prefix}resetppt
┆  ║✼${EmojiBot} ${prefix}resetaki
┆  ║✼${EmojiBot} ${prefix}resetarttt
┆  ║✼${EmojiBot} ${prefix}resetarvelha
┆  ║✼${EmojiBot} ${prefix}resetarforca
┆  ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉`

}

exports.brincadeiras = brincadeiras
