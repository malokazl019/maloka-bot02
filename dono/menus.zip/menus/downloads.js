const menudw = (prefix, EmojiBot) => {
return ` 
╭━━━━━◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║*${EmojiBot}️𝐏𝐄𝐒𝐐𝐔𝐈𝐒𝐀 𝐄 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐒${EmojiBot}️* 
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝    
╰━━━━━◉ 
‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
╭═══════◉
┆     ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆     ║
┆     ║✼${EmojiBot} ${prefix}play-selec (nome)
┆     ║✼${EmojiBot} ${prefix}ytsearch (NOME)
┆     ║✼${EmojiBot} ${prefix}ytmp4 (LINK)
┆     ║✼${EmojiBot} ${prefix}ytmp3 (LINK)
┆     ║✼${EmojiBot} ${prefix}spotify (NOME/LINK)
┆     ║✼${EmojiBot} ${prefix}tiktok (LINK)
┆     ║✼${EmojiBot} ${prefix}twitter (LINK)
┆     ║✼${EmojiBot} ${prefix}instagram (LINK)
┆     ║✼${EmojiBot} ${prefix}facebook (LINK)
┆     ║✼${EmojiBot} ${prefix}igstalk (off)
┆     ║✼${EmojiBot} ${prefix}mediafire (LINK)
┆     ║✼${EmojiBot} ${prefix}mediafire2 (LINK)
┆     ║✼${EmojiBot} ${prefix}gerarlink (MARCAR-I)
┆     ║✼${EmojiBot} ${prefix}Wikimedia (NOME)
┆     ║✼${EmojiBot} ${prefix}gerarlink (MARCAR-V)
┆     ║✼${EmojiBot} ${prefix}tomp3 (MARCAR-V)
┆     ║✼${EmojiBot} ${prefix}totext (MARCAR-A)
┆     ║✼${EmojiBot} ${prefix}letram (NOME DA MÚSICA)
┆     ║✼${EmojiBot} ${prefix}gifparawpp (LINK)
┆     ║✼${EmojiBot} ${prefix}gitclone (LIMK)
┆     ║✼${EmojiBot} ${prefix}playstore  (PESQUISA)
┆     ║✼${EmojiBot} ${prefix}gimage (PESQUISA IMAGEM)
┆     ║✼${EmojiBot} ${prefix}shorts (Link)
┆     ║
┆     ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉
 `
}

exports.menudw = menudw