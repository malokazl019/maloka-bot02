const menuanime = (prefix, NomeDoBot, EmojiBot) => {
  
// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
return `
╭━━━━━◉                              
┆   ╔┉✼┉═༺◈✼${EmojiBot}✼◈༻═┉✼┉╗   
         *${EmojiBot}𝐌𝐄𝐍𝐔 𝐀𝐍𝐈𝐌𝐄${EmojiBot}* 
┆   ╚┉✼┉═༺◈✼${EmojiBot}✼◈༻═┉✼┉╝   
╰━━━━━◉                  
‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
▢  ʙᴇᴍ ᴠɪɴᴅᴏ ᴀᴏ ᴍᴇɴᴜ ᴅᴇ ᴀɴɪᴍᴇ ▢ 
╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║
┆    ║✼${EmojiBot} ${prefix}animets ainz
┆    ║✼${EmojiBot} ${prefix}animets nami
┆    ║✼${EmojiBot} ${prefix}animets anya
┆    ║✼${EmojiBot} ${prefix}animets kurumi
┆    ║✼${EmojiBot} ${prefix}animets aqua
┆    ║✼${EmojiBot} ${prefix}animets naofumi
┆    ║✼${EmojiBot} ${prefix}animets dabi
┆    ║✼${EmojiBot} ${prefix}animets loli
┆    ║✼${EmojiBot} ${prefix}animets asta
┆    ║✼${EmojiBot} ${prefix}animets draken
┆    ║✼${EmojiBot} ${prefix}animets naruto
┆    ║✼${EmojiBot} ${prefix}animets madara
┆    ║✼${EmojiBot} ${prefix}animets asuna
┆    ║✼${EmojiBot} ${prefix}animets nezuko
┆    ║✼${EmojiBot} ${prefix}animets esdeath
┆    ║✼${EmojiBot} ${prefix}animets megumin
┆    ║✼${EmojiBot} ${prefix}animets ayuzawa
┆    ║✼${EmojiBot} ${prefix}animets noelle
┆    ║✼${EmojiBot} ${prefix}animets goku
┆    ║✼${EmojiBot} ${prefix}animets miku
┆    ║✼${EmojiBot} ${prefix}animets boruto
┆    ║✼${EmojiBot} ${prefix}animets power
┆    ║✼${EmojiBot} ${prefix}animets hinata
┆    ║✼${EmojiBot} ${prefix}animets minato
┆    ║✼${EmojiBot} ${prefix}animets cha-hae-in
┆    ║✼${EmojiBot} ${prefix}animets reiayanami
┆    ║✼${EmojiBot} ${prefix}animets ichigo
┆    ║✼${EmojiBot} ${prefix}animets onepiece
┆    ║✼${EmojiBot} ${prefix}animets chichi
┆    ║✼${EmojiBot} ${prefix}animets kanna
┆    ║✼${EmojiBot} ${prefix}animets saorikido
┆    ║✼${EmojiBot} ${prefix}animets chiho
┆    ║✼${EmojiBot} ${prefix}animets sagiri
┆    ║✼${EmojiBot} ${prefix}animets chitoge
┆    ║✼${EmojiBot} ${prefix}animets satoru
┆    ║✼${EmojiBot} ${prefix}animets killua
┆    ║✼${EmojiBot} ${prefix}animets sakura
┆    ║✼${EmojiBot} ${prefix}animets deidara
┆    ║✼${EmojiBot} ${prefix}animets seiya
┆    ║✼${EmojiBot} ${prefix}animets kirito
┆    ║✼${EmojiBot} ${prefix}animets sasuke
┆    ║✼${EmojiBot} ${prefix}animets elaina
┆    ║✼${EmojiBot} ${prefix}animets shina
┆    ║✼${EmojiBot} ${prefix}animets elizabeth
┆    ║✼${EmojiBot} ${prefix}animets sungjinwoo 
┆    ║✼${EmojiBot} ${prefix}animets levi
┆    ║✼${EmojiBot} ${prefix}animets shinomiya
┆    ║✼${EmojiBot} ${prefix}animets emilia
┆    ║✼${EmojiBot} ${prefix}animets tanjiro
┆    ║✼${EmojiBot} ${prefix}animets light
┆    ║✼${EmojiBot} ${prefix}animets shota
┆    ║✼${EmojiBot} ${prefix}animets eren-yaeger
┆    ║✼${EmojiBot} ${prefix}animets tatsumaki
┆    ║✼${EmojiBot} ${prefix}animets loid
┆    ║✼${EmojiBot} ${prefix}animets tejina
┆    ║✼${EmojiBot} ${prefix}animets erza
┆    ║✼${EmojiBot} ${prefix}animets tatsumi
┆    ║✼${EmojiBot} ${prefix}animets lucy
┆    ║✼${EmojiBot} ${prefix}animets toukachan
┆    ║✼${EmojiBot} ${prefix}animets gremory
┆    ║✼${EmojiBot} ${prefix}animets yumeko
┆    ║✼${EmojiBot} ${prefix}animets luffy
┆    ║✼${EmojiBot} ${prefix}animets tsunade
┆    ║✼${EmojiBot} ${prefix}animets hestia
┆    ║✼${EmojiBot} ${prefix}animets zero-two
┆    ║✼${EmojiBot} ${prefix}animets marin
┆    ║✼${EmojiBot} ${prefix}animets inori
┆    ║✼${EmojiBot} ${prefix}animets zoro
┆    ║✼${EmojiBot} ${prefix}animets meliodas
┆    ║✼${EmojiBot} ${prefix}animets waifu2
┆    ║✼${EmojiBot} ${prefix}animets isuzu
┆    ║✼${EmojiBot} ${prefix}animets akame
┆    ║✼${EmojiBot} ${prefix}animets mikasa
┆    ║✼${EmojiBot} ${prefix}animets yotsuba
┆    ║✼${EmojiBot} ${prefix}animets itori
┆    ║✼${EmojiBot} ${prefix}animets akira
┆    ║✼${EmojiBot} ${prefix}animets mikey
┆    ║✼${EmojiBot} ${prefix}animets yuki
┆    ║✼${EmojiBot} ${prefix}animets misa
┆    ║✼${EmojiBot} ${prefix}animets akiyama
┆    ║✼${EmojiBot} ${prefix}animets kaga
┆    ║✼${EmojiBot} ${prefix}animets mitsuri
┆    ║✼${EmojiBot} ${prefix}animets albedo
┆    ║✼${EmojiBot} ${prefix}animets kaori
┆    ║✼${EmojiBot} ${prefix}animets nagatoro
┆    ║✼${EmojiBot} ${prefix}animets ana
┆    ║✼${EmojiBot} ${prefix}animets kotori
┆    ║✼${EmojiBot} ${prefix}animets Stella
┆    ║✼${EmojiBot} ${prefix}animets Shinobu
┆    ║✼${EmojiBot} ${prefix}animets Mereoleona
┆    ║✼${EmojiBot} ${prefix}animets Sukuna
┆    ║✼${EmojiBot} ${prefix}animets Sanji
┆    ║✼${EmojiBot} ${prefix}animets Nagi
┆    ║✼${EmojiBot} ${prefix}animets Vegeta
┆    ║✼${EmojiBot} ${prefix}animets Komi
┆    ║✼${EmojiBot} ${prefix}animets Saitama
┆    ║✼${EmojiBot} ${prefix}animets Shinra
┆    ║✼${EmojiBot} ${prefix}animets rize
┆    ║
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉
`
}

exports.menuanime = menuanime

// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.
