const menux = (prefix, EmojiBot) => {
return `
╭━━━━━◉  
┆   ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗   
┆   ║       *${EmojiBot}️ 𝐌𝐞𝐧𝐮 +18 ${EmojiBot}️*             
┆   ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝   
╰━━━━━◉ 
​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​

╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║
┆    ║✼${EmojiBot} ${prefix}xvideos (pesquisa)
┆    ║✼${EmojiBot} ${prefix}xvideoslink (link)
┆    ║✼${EmojiBot} ${prefix}hentai (Video)
┆    ║✼${EmojiBot} ${prefix}plaq1 (txt)
┆    ║✼${EmojiBot} ${prefix}plaq2 (txt)
┆    ║✼${EmojiBot} ${prefix}plaq3 (txt)
┆    ║✼${EmojiBot} ${prefix}plaq4 (txt)
┆    ║✼${EmojiBot} ${prefix}plaq5 (txt)
┆    ║✼${EmojiBot} ${prefix}listadepacks
┆    ║
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉

    ༺◈✼${EmojiBot}️𝐈𝐌𝐀𝐆𝐄𝐍𝐒 𝐍𝐒𝐅𝐖${EmojiBot}️✼◈༻
    
╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║✼${EmojiBot} ${prefix}Nsfwts ahegao
┆    ║✼${EmojiBot} ${prefix}Nsfwts ass
┆    ║✼${EmojiBot} ${prefix}Nsfwts bdsm
┆    ║✼${EmojiBot} ${prefix}Nsfwts blowjob
┆    ║✼${EmojiBot} ${prefix}Nsfwts cuckold
┆    ║✼${EmojiBot} ${prefix}Nsfwts ero
┆    ║✼${EmojiBot} ${prefix}Nsfwts femdom
┆    ║✼${EmojiBot} ${prefix}Nsfwts foot
┆    ║✼${EmojiBot} ${prefix}Nsfwts gangbang
┆    ║✼${EmojiBot} ${prefix}Nsfwts glasses
┆    ║✼${EmojiBot} ${prefix}Nsfwts hentai
┆    ║✼${EmojiBot} ${prefix}Nsfwts jahy
┆    ║✼${EmojiBot} ${prefix}Nsfwts manga
┆    ║✼${EmojiBot} ${prefix}Nsfwts masturbation
┆    ║✼${EmojiBot} ${prefix}Nsfwts neko
┆    ║✼${EmojiBot} ${prefix}Nsfwts neko2
┆    ║✼${EmojiBot} ${prefix}Nsfwts orgy
┆    ║✼${EmojiBot} ${prefix}Nsfwts panties
┆    ║✼${EmojiBot} ${prefix}Nsfwts pussy
┆    ║✼${EmojiBot} ${prefix}Nsfwts tentacles
┆    ║✼${EmojiBot} ${prefix}Nsfwts Things 
┆    ║✼${EmojiBot} ${prefix}Nsfwts yuri
┆    ║✼${EmojiBot} ${prefix}Nsfwts zettai
┆    ║✼${EmojiBot} ${prefix}Nsfwts cum
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉

    ༺◈✼${EmojiBot}️𝐆𝐈𝐅𝐒 𝐍𝐒𝐅𝐖${EmojiBot}️✼◈༻
     
╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║✼${EmojiBot} ${prefix}Gif/loli
┆    ║✼${EmojiBot} ${prefix}Gif/ahegao
┆    ║✼${EmojiBot} ${prefix}Gif/ass
┆    ║✼${EmojiBot} ${prefix}Gif/bdsm
┆    ║✼${EmojiBot} ${prefix}Gif/blowjob
┆    ║✼${EmojiBot} ${prefix}Gif/ero
┆    ║✼${EmojiBot} ${prefix}Gif/femdom
┆    ║✼${EmojiBot} ${prefix}Gif/foot
┆    ║✼${EmojiBot} ${prefix}Gif/gangbang
┆    ║✼${EmojiBot} ${prefix}Gif/glasses
┆    ║✼${EmojiBot} ${prefix}Gif/masturbation
┆    ║✼${EmojiBot} ${prefix}Gif/neko
┆    ║✼${EmojiBot} ${prefix}Gif/orgy
┆    ║✼${EmojiBot} ${prefix}Gif/panties
┆    ║✼${EmojiBot} ${prefix}Gif/tentacles
┆    ║✼${EmojiBot} ${prefix}Gif/yuri
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉
`
}

exports.menux = menux