const menu = (prefix, NomeDoBot, EmojiBot) => {
  
// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
return `
╭━━━━━◉                              
┆   ╔┉✼┉═༺◈✼${EmojiBot}✼◈༻═┉✼┉╗   
┆   ║        *${EmojiBot}𝐌𝐄𝐍𝐔 𝐏𝐑𝐈𝐍𝐂𝐈𝐏𝐀𝐋${EmojiBot}*   
┆   ╚┉✼┉═༺◈✼${EmojiBot}✼◈༻═┉✼┉╝   
╰━━━━━◉                  
‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
▢ ⌁sᴇᴊᴀ ʙᴇᴍ ᴠɪɴᴅᴏ(ᴀ) ᴀᴏ ᴍᴇɴᴜ ᴅᴇ ᴄᴍᴅs⌁ ▢ 
╭━━━━━◉
┆   ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆   ║       *${EmojiBot}️𝐈𝐌𝐏𝐎𝐑𝐓𝐀𝐍𝐓𝐄${EmojiBot}️*         
┆   ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰━━━━━◉
╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║
┆    ║✼${EmojiBot} ${prefix}admins
┆    ║✼${EmojiBot} ${prefix}dono
┆    ║✼${EmojiBot} ${prefix}convite (link)
┆    ║✼${EmojiBot} ${prefix}cep
┆    ║✼${EmojiBot} ${prefix}imc peso|altura
┆    ║✼${EmojiBot} ${prefix}logosite link
┆    ║✼${EmojiBot} ${prefix}InfoBemvindo
┆    ║✼${EmojiBot} ${prefix}Infopalavrão
┆    ║✼${EmojiBot} ${prefix}Infolistanegra
┆    ║✼${EmojiBot} ${prefix}Infobancarac
┆    ║✼${EmojiBot} ${prefix}Infovotação
┆    ║✼${EmojiBot} ${prefix}Infocontador
┆    ║✼${EmojiBot} ${prefix}Infosorteio
┆    ║✼${EmojiBot} ${prefix}Infobot
┆    ║✼${EmojiBot} ${prefix}Idiomas
┆    ║✼${EmojiBot} ${prefix}Metodos
┆    ║✼${EmojiBot} ${prefix}tomp3
┆    ║✼${EmojiBot} ${prefix}totext
┆    ║✼${EmojiBot} ${prefix}Bug (questione)
┆    ║✼${EmojiBot} ${prefix}Avalie (o quao bom)
┆    ║✼${EmojiBot} ${prefix}Sugestao (dica)
┆    ║
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉
╭━━━━━◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║       *${EmojiBot}️𝐌𝐄𝐍𝐔-𝐃𝐄-𝐂𝐌𝐃${EmojiBot}️*         
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝    
╰━━━━━◉
╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║
┆    ║✼${EmojiBot} ${prefix}Menudono
┆    ║✼${EmojiBot} ${prefix}menuefeitos
┆    ║✼${EmojiBot} ${prefix}Menuadm
┆    ║✼${EmojiBot} ${prefix}Menufig
┆    ║✼${EmojiBot} ${prefix}Menudw
┆    ║✼${EmojiBot} ${prefix}Menuanime
┆    ║✼${EmojiBot} ${prefix}Menupremium
┆    ║✼${EmojiBot} ${prefix}Menugold
┆    ║✼${EmojiBot} ${prefix}Menu18
┆    ║✼${EmojiBot} ${prefix}menulogos
┆    ║✼${EmojiBot} ${prefix}Brincadeiras
┆    ║✼${EmojiBot} ${prefix}Alteradores
┆    ║
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉
╭━━━━━◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║       *${EmojiBot}️𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐂𝐎𝐄𝐒${EmojiBot}️*      
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝    
╰━━━━━◉
╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║
┆    ║✼${EmojiBot}️ ${prefix}tabelacamp
┆    ║✼${EmojiBot}️ ${prefix}meutime time
┆    ║✼${EmojiBot} ${prefix}Ping (velo)
┆    ║✼${EmojiBot} ${prefix}Atividade
┆    ║✼${EmojiBot} ${prefix}Rankativo
┆    ║✼${EmojiBot} ${prefix}Checkativo @marcar
┆    ║✼${EmojiBot} ${prefix}Ranklevel (de todos)
┆    ║
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉
╭━━━━━◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║       *${EmojiBot}️𝐂𝐌𝐃𝐒-𝐁𝐀𝐒𝐈𝐂𝐎𝐒${EmojiBot}️*      
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝    
╰━━━━━◉
╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║
┆    ║✼${EmojiBot} ${prefix}Gtts (língua+txt)
┆    ║✼${EmojiBot} ${prefix}Tagme
┆    ║✼${EmojiBot} ${prefix}wame
┆    ║✼${EmojiBot} ${prefix}traduzir (A Palavra)
┆    ║✼${EmojiBot} ${prefix}Tabela (LETRAS) 
┆    ║✼${EmojiBot} ${prefix}Conselhobiblico
┆    ║✼${EmojiBot} ${prefix}Simi (fale algo) 
┆    ║✼${EmojiBot} ${prefix}Perfil
┆    ║✼${EmojiBot} ${prefix}Calcular (numero)
┆    ║✼${EmojiBot} ${prefix}Fazernick (nick)
┆    ║✼${EmojiBot} ${prefix}Esdeath
┆    ║✼${EmojiBot} ${prefix}jogos
┆    ║✼${EmojiBot} Prefixo: ⟪•  ${prefix}  •⟫
┆    ║
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉
`
}

exports.menu = menu

// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.
