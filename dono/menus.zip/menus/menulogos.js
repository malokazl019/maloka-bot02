const menulogos = (prefix, EmojiBot) => {
  
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
  return `
╭━━━━━◉                  
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗    
┆    ║     *${EmojiBot}️𝐥𝐨𝐠𝐨𝐬 𝐝𝐞 𝐭𝐞𝐱𝐭𝐨${EmojiBot}️*  
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝    
╰━━━━━◉                  
  ​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​

╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║
┆    ║✼${EmojiBot}️  ${prefix}Txtquadrinhos (txt) 
┆    ║✼${EmojiBot}️  ${prefix}HackNeon (txt) 
┆    ║✼${EmojiBot}️  ${prefix}EquipeMascote (txt) 
┆    ║✼${EmojiBot}️  ${prefix}FFavatar (txt) 
┆    ║✼${EmojiBot}️  ${prefix}Gizquadro (txt) 
┆    ║✼${EmojiBot}️  ${prefix}Angelglx (txt) 
┆    ║✼${EmojiBot}️  ${prefix}WingEffect (txt) 
┆    ║✼${EmojiBot}️  ${prefix}Angelwing (txt) 
┆    ║✼${EmojiBot}️  ${prefix}Blackpink (txt) 
┆    ║✼${EmojiBot}️  ${prefix}Girlmascote (txt) 
┆    ║✼${EmojiBot}️  ${prefix}Mascotegame (txt) 
┆    ║✼${EmojiBot}️  ${prefix}Fpsmascote (txt) 
┆    ║✼${EmojiBot}️  ${prefix}Logogame (txt) 
┆    ║✼${EmojiBot}️  ${prefix}Glitch2 (txt) 
┆    ║✼${EmojiBot}️  ${prefix}3DGold (txt)
┆    ║✼${EmojiBot}️  ${prefix}Placaloli (txt)
┆    ║✼${EmojiBot}️  ${prefix}Phadow (txt)
┆    ║✼${EmojiBot}️  ${prefix}Efeitoneon (txt)
┆    ║✼${EmojiBot}️  ${prefix}Cemiterio (txt)
┆    ║✼${EmojiBot}️  ${prefix}Metalgold (txt)
┆    ║✼${EmojiBot}️  ${prefix}Narutologo (txt)
┆    ║✼${EmojiBot}️  ${prefix}Fire (txt)
┆    ║✼${EmojiBot}️  ${prefix}Romantic (txt)
┆    ║✼${EmojiBot}️  ${prefix}Smoke (txt)
┆    ║✼${EmojiBot}️  ${prefix}Papel (txt)
┆    ║✼${EmojiBot}️  ${prefix}Lovemsg (txt)
┆    ║✼${EmojiBot}️  ${prefix}Lovemsg2 (txt)
┆    ║✼${EmojiBot}️  ${prefix}Lovemsg3 (txt)
┆    ║✼${EmojiBot}️  ${prefix}Coffecup (txt)
┆    ║✼${EmojiBot}️  ${prefix}Coffecup2 (txt)
┆    ║✼${EmojiBot}️  ${prefix}Cup (txt)
┆    ║✼${EmojiBot}️  ${prefix}Florwooden (txt)
┆    ║✼${EmojiBot}️  ${prefix}Lobometal (txt)
┆    ║✼${EmojiBot}️  ${prefix}Harryp (txt)
┆    ║✼${EmojiBot}️  ${prefix}Txtborboleta (txt)
┆    ║✼${EmojiBot}️  ${prefix}Madeira (txt)
┆    ║✼${EmojiBot}️  ${prefix}Pornhub (txt)
┆    ║✼${EmojiBot}️  ${prefix}Escudo (txt)
┆    ║✼${EmojiBot}️  ${prefix}Transformer (txt)
┆    ║✼${EmojiBot}️  ${prefix}America (txt)
┆    ║✼${EmojiBot}️  ${prefix}Demongreen (txt)
┆    ║✼${EmojiBot}️  ${prefix}Wetglass (txt)    
┆    ║✼${EmojiBot}️  ${prefix}Toxic (txt)    
┆    ║✼${EmojiBot}️  ${prefix}Neon3 (txt)   
┆    ║✼${EmojiBot}️  ${prefix}Neondevil (txt) 
┆    ║✼${EmojiBot}️  ${prefix}Neongreen (txt)
┆    ║✼${EmojiBot}️  ${prefix}Lava (txt)
┆    ║✼${EmojiBot}️  ${prefix}Halloween (txt)
┆    ║✼${EmojiBot}️  ${prefix}Neondevil (txt)
┆    ║✼${EmojiBot}️  ${prefix}DemonFire (txt)
┆    ║✼${EmojiBot}️  ${prefix}DemonGreen (txt)
┆    ║✼${EmojiBot}️  ${prefix}Thunderv2 (txt)
┆    ║✼${EmojiBot}️  ${prefix}Thunder (txt)
┆    ║✼${EmojiBot}️  ${prefix}Colaq (txt)
┆    ║✼${EmojiBot}️  ${prefix}Luxury (txt)
┆    ║✼${EmojiBot}️  ${prefix}Berry (txt)
┆    ║✼${EmojiBot}️  ${prefix}Transformer (txt)
┆    ║✼${EmojiBot}️  ${prefix}Matrix (txt)
┆    ║✼${EmojiBot}️  ${prefix}Horror (txt)
┆    ║✼${EmojiBot}️  ${prefix}Nuvem (txt)
┆    ║✼${EmojiBot}️  ${prefix}Neon (txt)
┆    ║✼${EmojiBot}️  ${prefix}Neon1 (txt)
┆    ║✼${EmojiBot}️  ${prefix}Neon2 (txt)
┆    ║✼${EmojiBot}️  ${prefix}Neon3d (txt)
┆    ║✼${EmojiBot}️  ${prefix}NeonGreen (txt)
┆    ║✼${EmojiBot}️  ${prefix}Neon3 (txt)
┆    ║✼${EmojiBot}️  ${prefix}Neve (txt)
┆    ║✼${EmojiBot}️  ${prefix}Areia (txt)
┆    ║✼${EmojiBot}️  ${prefix}Vidro (txt)
┆    ║✼${EmojiBot}️  ${prefix}Style (txt)
┆    ║✼${EmojiBot}️  ${prefix}Pink (txt)
┆    ║✼${EmojiBot}️  ${prefix}Carbon (txt)
┆    ║✼${EmojiBot}️  ${prefix}Tetalblue (txt)
┆    ║✼${EmojiBot}️  ${prefix}Toxic (txt)
┆    ║✼${EmojiBot}️  ${prefix}Jeans (txt)
┆    ║✼${EmojiBot}️  ${prefix}Ossos (txt)
┆    ║✼${EmojiBot}️  ${prefix}Asfalto (txt)
┆    ║✼${EmojiBot}️  ${prefix}Natal (txt)
┆    ║✼${EmojiBot}️  ${prefix}Joker (txt)
┆    ║✼${EmojiBot}️  ${prefix}Blood (txt)
┆    ║✼${EmojiBot}️  ${prefix}Break (txt)
┆    ║✼${EmojiBot}️  ${prefix}Fiction (txt)
┆    ║✼${EmojiBot}️  ${prefix}3dstone (txt)
┆    ║✼${EmojiBot}️  ${prefix}Lapis (txt)
┆    ║✼${EmojiBot}️  ${prefix}Gelo (txt)
┆    ║✼${EmojiBot}️  ${prefix}Rainbow (txt)
┆    ║✼${EmojiBot}️  ${prefix}Metalfire (txt)
┆    ║
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉

╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗    
┆    ║     *${EmojiBot}️𝐥𝐨𝐠𝐨𝐬 𝐝𝐞 𝐭𝐞𝐱𝐭𝐨2${EmojiBot}️* 
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝    
╰═══════◉

╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║
┆    ║✼${EmojiBot}️  ${prefix}Comporn (txt/txt) 
┆    ║✼${EmojiBot}️  ${prefix}Glitch (txt/txt)
┆    ║✼${EmojiBot}️  ${prefix}Glitch3 (txt/txt)
┆    ║✼${EmojiBot}️  ${prefix}Grafity (txt-txt)
┆    ║✼${EmojiBot}️  ${prefix}Space (txt/txt)
┆    ║✼${EmojiBot}️  ${prefix}Marvel (txt/txt)
┆    ║✼${EmojiBot}️  ${prefix}GamePlay (txt/txt)
┆    ║✼${EmojiBot}️  ${prefix}Stone (txt/txt)
┆    ║✼${EmojiBot}️  ${prefix}Steel (txt/txt)
┆    ║✼${EmojiBot}️  ${prefix}Ffbanner (txt/txt) 
┆    ║✼${EmojiBot}️  ${prefix}Mascoteavatar (txt/txt) 
┆    ║
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉`
}

exports.menulogos = menulogos

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 