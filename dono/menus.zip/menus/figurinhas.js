const menufig = (prefix, EmojiBot) => {
return `
╭━━━━━◉        
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║     *${EmojiBot}️𝐅𝐈𝐆𝐔𝐑𝐈𝐍𝐇𝐀𝐒${EmojiBot}️*    
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝    
╰━━━━━◉      
‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
╭═══════◉
┆    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆    ║
┆    ║✼${EmojiBot} ${prefix}Attp  (txt)
┆    ║✼${EmojiBot} ${prefix}Attp2  (txt)
┆    ║✼${EmojiBot} ${prefix}Attp3  (txt)
┆    ║✼${EmojiBot} ${prefix}Attp4  (txt)
┆    ║✼${EmojiBot} ${prefix}Attp5  (txt)
┆    ║✼${EmojiBot} ${prefix}Attp6  (txt)
┆    ║✼${EmojiBot} ${prefix}Ttp (txt)
┆    ║✼${EmojiBot} ${prefix}Ttp2 (txt)
┆    ║✼${EmojiBot} ${prefix}Ttp3 (txt)
┆    ║✼${EmojiBot} ${prefix}Ttp4 (txt)
┆    ║✼${EmojiBot} ${prefix}Ttp5 (txt)
┆    ║✼${EmojiBot} ${prefix}Ttp6 (txt)
┆    ║✼${EmojiBot} ${prefix}Sfundo
┆    ║✼${EmojiBot} ${prefix}emoji
┆    ║✼${EmojiBot} ${prefix}emojimix (🙂+🤭)
┆    ║✼${EmojiBot} ${prefix}Fsticker (Ou ${prefix}F)
┆    ║✼${EmojiBot} ${prefix}Sticker  (Ou ${prefix}S)
┆    ║✼${EmojiBot} ${prefix}Togif
┆    ║✼${EmojiBot} ${prefix}Toimg
┆    ║✼${EmojiBot} ${prefix}legenda
┆    ║✼${EmojiBot} ${prefix}triggered
┆    ║✼${EmojiBot} ${prefix}placaloli (txt)
┆    ║✼${EmojiBot} ${prefix}pesquisarfig (NOME)
┆    ║✼${EmojiBot} ${prefix}packsfigs
┆    ║✼${EmojiBot} ${prefix}telesticker (LINK)
┆    ║✼${EmojiBot} ${prefix}figurinhas (QUANTIDADE)
┆    ║✼${EmojiBot} ${prefix}figemoji
┆    ║✼${EmojiBot} ${prefix}figroblox
┆    ║✼${EmojiBot} ${prefix}figmeme
┆    ║✼${EmojiBot} ${prefix}figanime
┆    ║✼${EmojiBot} ${prefix}figcoreana
┆    ║✼${EmojiBot} ${prefix}figraiva
┆    ║✼${EmojiBot} ${prefix}figengracada
┆    ║✼${EmojiBot} ${prefix}figdesenho
┆    ║
┆    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉

`
}

exports.menufig = menufig