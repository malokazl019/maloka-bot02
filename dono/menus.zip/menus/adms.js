const adms = (prefix, EmojiBot) => { 
 
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

	return `
╭━━━━━◉  
    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗   
    ║       *👮‍♀️𝐌𝐄𝐍𝐔 𝐀𝐃𝐌👮‍♂️*           
    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝   
╰━━━━━◉ 
‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎‏‎
▢ ⌁ᴍᴇɴᴜ ᴀᴅᴍ,ғᴇɪᴛᴏ ᴘᴀʀᴀ ᴀᴘᴇɴᴀs ᴀᴅᴍɪɴɪsᴛʀᴀᴅᴏʀ ᴅᴏ ɢʀᴜᴘᴏ⌁ ▢ 
╭═══════◉
┆      ╔┉✼┉═༺✼${EmojiBot}️✼༻═┉✼┉╗
┆      ║
┆      ║✼${EmojiBot} ${prefix}ban (marc msg ou o @)
┆      ║✼${EmojiBot} ${prefix}ban2 (banir com tempo)
┆      ║✼${EmojiBot} ${prefix}promover [@] (promover adm)
┆      ║✼${EmojiBot} ${prefix}rebaixar [@] (rebaixar adm)
┆      ║✼${EmojiBot} ${prefix}totag (menciona-algo)
┆      ║✼${EmojiBot} ${prefix}advertencia (marca msg)
┆      ║✼${EmojiBot} ${prefix}advertidos
┆      ║✼${EmojiBot} ${prefix}removeradvertencia
┆      ║✼${EmojiBot}️ ${prefix}blockcmd-temp (comando)
┆      ║✼${EmojiBot}️ ${prefix}unblockcmd-temp 
┆      ║✼${EmojiBot}️ ${prefix}listacomandos-temp
┆      ║✼${EmojiBot}️ ${prefix}listacomunidades
┆      ║✼${EmojiBot}️ ${prefix}mensagem-automatica
┆      ║✼${EmojiBot} ${prefix}lista-mensagens-automaticas
┆      ║✼${EmojiBot} ${prefix}dl-mensagem-automatica
┆      ║✼${EmojiBot} ${prefix}fechar-abrirgp
┆      ║✼${EmojiBot} ${prefix}tirar-fechar-abrirgp
┆      ║✼${EmojiBot} ${prefix}check-time
┆      ║✼${EmojiBot} ${prefix}sorteio
┆      ║✼${EmojiBot} ${prefix}sorteionumero
┆      ║✼${EmojiBot} ${prefix}status
┆      ║✼${EmojiBot} ${prefix}admins
┆      ║✼${EmojiBot} ${prefix}destrava
┆      ║✼${EmojiBot} ${prefix}destrava2
┆      ║✼${EmojiBot} ${prefix}digt
┆      ║✼${EmojiBot} ${prefix}aceitarmembro
┆      ║✼${EmojiBot} ${prefix}regraspp
┆      ║✼${EmojiBot} ${prefix}apresentar
┆      ║✼${EmojiBot} ${prefix}limpar (texto-invisível-gp)
┆      ║✼${EmojiBot} ${prefix}atividades (DO-GRUPO)
┆      ║✼${EmojiBot} ${prefix}linkgp
┆      ║✼${EmojiBot} ${prefix}listagp2
┆      ║✼${EmojiBot} ${prefix}infogp
┆      ║✼${EmojiBot} ${prefix}listafake
┆      ║✼${EmojiBot} ${prefix}listanegra (559numero)
┆      ║✼${EmojiBot} ${prefix}tirardalista
┆      ║✼${EmojiBot} ${prefix}listaband
┆      ║✼${EmojiBot} ${prefix}fechar-abrirgp 
┆      ║✼${EmojiBot} ${prefix}hidetag (txt) (marcação)
┆      ║✼${EmojiBot} ${prefix}marcar (marca Tds - Adms)
┆      ║✼${EmojiBot} ${prefix}marcar2 (Marca Todos)
┆      ║✼${EmojiBot} ${prefix}marcarwa (wa me)
┆      ║
┆      ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰━━━━━◉ 
    
╭━━━━━◉  
    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗   
    ║       *👑𝐀𝐓𝐈𝐕𝐀𝐂̧𝐎̃𝐄𝐒👑*
    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝   
╰━━━━━◉ 
▢ ⌁ᴍᴇɴᴜ ᴀᴅᴍ,ғᴇɪᴛᴏ ᴘᴀʀᴀ ᴀᴘᴇɴᴀs ᴀᴅᴍɪɴɪsᴛʀᴀᴅᴏʀ ᴅᴏ ɢʀᴜᴘᴏ⌁ ▢ 
╭═══════◉
┆      ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆      ║
┆      ║✼${EmojiBot} ${prefix}autoresposta 1 / 0
┆      ║✼${EmojiBot} ${prefix}modo+18 1 / 0
┆      ║✼${EmojiBot} ${prefix}anagrama 1 / 0
┆      ║✼${EmojiBot} ${prefix}Autofigu 1 / 0
┆      ║✼${EmojiBot} ${prefix}antipalavra 1 / 0
┆      ║✼${EmojiBot} ${prefix}antidocumento 1 / 0  
┆      ║✼${EmojiBot} ${prefix}antiloc 1 / 0  
┆      ║✼${EmojiBot} ${prefix}anticontato 1 / 0  
┆      ║✼${EmojiBot} ${prefix}antinotas 1 / 0
┆      ║✼${EmojiBot} ${prefix}antilink 1 / 0
┆      ║✼${EmojiBot} ${prefix}antilinkgp 1 / 0
┆      ║✼${EmojiBot} ${prefix}antilinkhard 1 / 0
┆      ║✼${EmojiBot} ${prefix}x9visuunica 1 / 0
┆      ║✼${EmojiBot} ${prefix}antiporno 1 / 0
┆      ║✼${EmojiBot}️ ${prefix}antipalavrão 1 / 0
┆      ║✼${EmojiBot} ${prefix}antifake 1 / 0
┆      ║✼${EmojiBot} ${prefix}antimarc 1 / 0
┆      ║✼${EmojiBot} ${prefix}antiimg 1 / 0
┆      ║✼${EmojiBot} ${prefix}antiaudio 1 / 0
┆      ║✼${EmojiBot} ${prefix}antivideo 1 / 0
┆      ║✼${EmojiBot} ${prefix}antisticker 1 / 0
┆      ║✼${EmojiBot} ${prefix}limitecaracteres  1 / 0
┆      ║✼${EmojiBot} ${prefix}modobrincadeira  1 / 0
┆      ║✼${EmojiBot} ${prefix}leveling 1 / 0  
┆      ║✼${EmojiBot} ${prefix}simih 1 / 0
┆      ║✼${EmojiBot} ${prefix}simih2 1 / 0
┆      ║✼${EmojiBot}️ ${prefix}so_adm 1 / 0
┆      ║
┆      ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰━━━━━◉ 
    
╭━━━━━◉  
    ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗   
    ║   *💎𝐂𝐎𝐍𝐅𝐈𝐆𝐔𝐑𝐀𝐑-𝐆𝐏💎*
    ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝   
╰━━━━━◉ 
▢ ⌁ᴍᴇɴᴜ ᴀᴅᴍ,ғᴇɪᴛᴏ ᴘᴀʀᴀ ᴀᴘᴇɴᴀs ᴀᴅᴍɪɴɪsᴛʀᴀᴅᴏʀ ᴅᴏ ɢʀᴜᴘᴏ⌁ ▢ 
╭━━━━━◉  
┆      ╔┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╗
┆      ║
┆      ║✼${EmojiBot} ${prefix}fotogp (Marca)
┆      ║✼${EmojiBot} ${prefix}descgp (TXT)
┆      ║✼${EmojiBot} ${prefix}Criartabela (ESCREVA-ALGO)
┆      ║✼${EmojiBot} ${prefix}nomegp (Nome)
┆      ║✼${EmojiBot} ${prefix}grupo f/a
┆      ║✼${EmojiBot} ${prefix}descriçãogp
┆      ║✼${EmojiBot} ${prefix}bemvindo 
┆      ║✼${EmojiBot} ${prefix}bemvindo2 
┆      ║✼${EmojiBot}️ ${prefix}fundobemvindo (marcar-img)
┆      ║✼${EmojiBot}️ ${prefix}fundosaiu (marcar-img)
┆      ║✼${EmojiBot} ${prefix}legendabv (com foto)
┆      ║✼${EmojiBot} ${prefix}legendabv2 (sem foto)
┆      ║✼${EmojiBot} ${prefix}legendasaiu (com foto)
┆      ║✼${EmojiBot} ${prefix}legendasaiu2 (sem foto)
┆      ║
┆      ╚┉✼┉═༺◈✼${EmojiBot}️✼◈༻═┉✼┉╝
╰═══════◉
`
}

exports.adms = adms

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 